<?php
if (isset($_GET["msg"])) {
    echo "reply: " . $_GET["msg"];
}
